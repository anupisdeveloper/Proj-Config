#!/bin/bash

HOST=13.232.75.114
USER=ubuntu
PASSWORD=12345678
PORT=22
APP_NAME=demo

cleanBuild() {
 rm -rf dist busa.zip deploy/dist
}


localBuildForAngular() {
 echo "..........................Installing Node Modules .................................."
 cd src/main/resources/webapp/ ; npm install
 echo "..........................Node Modules Installation Done.................................."
 
 echo "..........................Local build started for angular.................................."
 #cd src/main/resources/webapp/ ; ng build --prod
 ls
 #cp -r dist/ webapp/
 echo "..........................Local build finished and copied to webapp.................................."
}

localBuildForMaven() {
echo "..........................Local build started for Maven.................................."
 ./mvnw clean install
 cp -r target/${APP_NAME}.war ${APP_NAME}/
 echo "..........................Local build finished and copied war file to ${APP_NAME}.................................."
}

copyAllRequiredFileAndZip() {
 echo "..........................Copy All Required file and Zip.................................."

 cp -r Dockerfile docker-deploy-development.sh ${APP_NAME}/
 #zip -r ${APP_NAME}.zip ${APP_NAME}/

 echo "..........................Ziped all Required File and ready for transfer.................................."
}

transferFileToRemote() {
 echo "..........................Transfering the file on remote server.................................."

 scp -i D:/credential/Busa_mml.pem ${APP_NAME}.zip ${USER}@${HOST}:~/
 #scp -i D:/credential/Busa_mml.pem busa.war ${USER}@${HOST}:~/Projects/busa_server

 echo "..........................File Transfered Successed.................................."
}

connectRemoteServer() {
  echo "..........................connecting on remote server.................................."
  #ssh -i D:/credential/Busa_mml.pem ${USER}@${HOST}
  sshpass -f <(printf '%s\n' D:/credential/Busa_mml.pem) ssh -p ${PORT} ${USER}@${HOST}
  cd Projects/busa-mml/BUSA_Server/busa_client_server/deploy/
  unzip busa.zip
}

#cleanBuild
#localBuild
localBuildForAngular
#localBuildForMaven
#copyAllRequiredFileAndZip
#transferFileToRemote
