#!/bin/bash

docker rm -f busa
docker rmi -f $(docker images | grep "<none>" | awk "{print \$3}")
docker rmi -f $(docker images | grep "busa" | awk "{print \$3}")
docker build -t busa .
# Enable for tagging
#docker tag busa <username>/busa

sleep 10

docker run --name busa -d -p 8080:8080 busa

